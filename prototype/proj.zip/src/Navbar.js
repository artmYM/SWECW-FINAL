import fdm_logo from "./assets/fdm.png";
import { Link, useLocation, useNavigate } from "react-router-dom";
import "./Navbar.css";
import { Button } from "./Button.js";

function Navbar() {
  const location = useLocation();
  const navigate = useNavigate();

  // Check if current route is a dashboard
  const isOnDashboard = location.pathname.toLowerCase().includes("dashboard");


  const handleLogout = () => {
    navigate("/login");
  };

  return (
    <nav className="navbar">
      <div className="navbar-container">
        <Link to="/" className="navbar-logo">
          <img src={fdm_logo} alt="FDM logo" />
        </Link>

        {/* Show Logout on dashboard, Login everywhere else */}
        {isOnDashboard ? (
          <Button buttonStyle="btn--outline" onClick={handleLogout}>
            LOGOUT
          </Button>
        ) : (
          <Link to="/login">
            <Button buttonStyle="btn--outline">LOGIN</Button>
          </Link>
        )}
      </div>
    </nav>
  );
}

export default Navbar;
