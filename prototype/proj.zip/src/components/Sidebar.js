import React from "react";
import { Link } from "react-router-dom";

const Sidebar = ({ user }) => {
  const menuItems = [
    { label: "Submit Timesheet", path: "/submit-timesheet", roles: ["consultant"] },
    { label: "Pending Timesheets", path: "/managerdashboard?status=submitted", roles: ["manager"] },
    { label: "Approved Timesheets", path: "/managerdashboard?status=approved", roles: ["manager"] },
    { label: "Rejected Timesheets", path: "/managerdashboard?status=rejected", roles: ["manager"] },
    { label: "All Timesheets", path: "/managerdashboard?status=all", roles: ["manager"] },
    { label: "Payroll Processing", path: "/payroll", roles: ["accountant"] },
    { label: "Manage Users", path: "/manage-users", roles: ["admin"] },
    { label: "Settings", path: "/settings", roles: ["consultant", "manager", "accountant", "admin"] },
  ];
  

  return (
    <aside style={{ width: "250px", background: "#222", color: "#fff", padding: "20px" }}>
      <h2>Timesheet System</h2>
      <nav>
        <ul style={{ listStyle: "none", padding: 0 }}>
          {menuItems.map((item) =>
            item.roles.includes(user.role.toLowerCase()) ? (
              <li key={item.path}>
                <Link to={item.path} style={{ color: "#fff", textDecoration: "none", display: "block", padding: "10px 0" }}>
                  {item.label}
                </Link>
              </li>
            ) : null
          )}
        </ul>
      </nav>
    </aside>
  );
};

export default Sidebar;
