import React, { useState } from "react";
import BaseDashboard from "./BaseDashboard";

const AdminDashboard = ({ user }) => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    role: "consultant",
    password: ""
  });

  const [users, setUsers] = useState([
    { name: "Alice Johnson", email: "alice@example.com", role: "consultant" },
    { name: "Bob Smith", email: "bob@example.com", role: "manager" },
  ]);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.password) {
      alert("Please fill out all fields.");
      return;
    }
    setUsers([...users, formData]);
    setFormData({ name: "", email: "", role: "consultant", password: "" });
    alert("User added (not saved - demo only)");
  };

  return (
    <BaseDashboard title="Admin Dashboard" user={user}>
      <h2>Add New User</h2>
      <form onSubmit={handleSubmit} style={{ maxWidth: "400px", marginBottom: "30px" }}>
        <div style={{ marginBottom: "10px" }}>
          <label>Full Name</label>
          <input
            type="text"
            name="name"
            value={formData.name}
            onChange={handleChange}
            style={{ width: "100%", padding: "8px" }}
          />
        </div>
        <div style={{ marginBottom: "10px" }}>
          <label>Email</label>
          <input
            type="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            style={{ width: "100%", padding: "8px" }}
          />
        </div>
        <div style={{ marginBottom: "10px" }}>
          <label>Role</label>
          <select
            name="role"
            value={formData.role}
            onChange={handleChange}
            style={{ width: "100%", padding: "8px" }}
          >
            <option value="consultant">Consultant</option>
            <option value="manager">Manager</option>
            <option value="admin">Admin</option>
          </select>
        </div>
        <div style={{ marginBottom: "10px" }}>
          <label>Password</label>
          <input
            type="password"
            name="password"
            value={formData.password}
            onChange={handleChange}
            style={{ width: "100%", padding: "8px" }}
          />
        </div>
        <button type="submit" style={{ padding: "10px 20px" }}>Add User</button>
      </form>

      <h2>Existing Users</h2>
      <table style={{ width: "100%", borderCollapse: "collapse" }}>
        <thead>
          <tr>
            <th style={{ borderBottom: "1px solid #ccc", textAlign: "left" }}>Name</th>
            <th style={{ borderBottom: "1px solid #ccc", textAlign: "left" }}>Email</th>
            <th style={{ borderBottom: "1px solid #ccc", textAlign: "left" }}>Role</th>
          </tr>
        </thead>
        <tbody>
          {users.map((u, index) => (
            <tr key={index}>
              <td style={{ padding: "8px 0" }}>{u.name}</td>
              <td>{u.email}</td>
              <td>{u.role}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </BaseDashboard>
  );
};

export default AdminDashboard;
