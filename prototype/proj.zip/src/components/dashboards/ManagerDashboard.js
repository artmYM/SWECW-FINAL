import React, { useState } from "react";
import BaseDashboard from "./BaseDashboard";

const ManagerDashboard = ({ user }) => {
  // Mock data for pending timesheets
  const [timesheets, setTimesheets] = useState([
    {
      id: 1,
      consultantName: "Alice Johnson",
      weekStart: "2024-03-25",
      totalHours: 37.5,
      status: "submitted"
    },
    {
      id: 2,
      consultantName: "Bob Smith",
      weekStart: "2024-03-25",
      totalHours: 40,
      status: "submitted"
    }
  ]);

  const handleApprove = (id) => {
    alert(`Approved timesheet ID: ${id}`);
    setTimesheets(timesheets.filter(ts => ts.id !== id));
  };

  const handleReject = (id) => {
    alert(`Rejected timesheet ID: ${id}`);
    setTimesheets(timesheets.filter(ts => ts.id !== id));
  };

  const handleViewDetails = (id) => {
    alert(`View details for timesheet ID: ${id}`);
  };

  return (
    <BaseDashboard title="Manager Dashboard" user={user}>
      <section>
        <h2>Pending Approvals</h2>
        <p>Approve or reject employee timesheets.</p>

        <table style={{ width: "100%", borderCollapse: "collapse", marginTop: "20px" }}>
          <thead>
            <tr>
              <th style={{ textAlign: "left", padding: "8px" }}>Consultant</th>
              <th style={{ textAlign: "left", padding: "8px" }}>Week Starting</th>
              <th style={{ textAlign: "left", padding: "8px" }}>Total Hours</th>
              <th style={{ textAlign: "left", padding: "8px" }}>Status</th>
              <th style={{ textAlign: "left", padding: "8px" }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {timesheets.map((ts) => (
              <tr key={ts.id}>
                <td style={{ padding: "8px" }}>{ts.consultantName}</td>
                <td>{ts.weekStart}</td>
                <td>{ts.totalHours}</td>
                <td>{ts.status}</td>
                <td>
                  <button onClick={() => handleViewDetails(ts.id)} style={{ marginRight: "10px" }}>
                    View Details
                  </button>
                  <button onClick={() => handleApprove(ts.id)} style={{ marginRight: "5px" }}>
                    Approve
                  </button>
                  <button onClick={() => handleReject(ts.id)}>
                    Reject
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>
    </BaseDashboard>
  );
};

export default ManagerDashboard;
