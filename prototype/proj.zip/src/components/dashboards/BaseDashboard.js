import React from "react";
import Sidebar from "../Sidebar";

const BaseDashboard = ({ children, title, user }) => {
  if (!user) return <h1>Loading...</h1>; // Prevents crash if `user` is undefined

  return (
    <div style={{ display: "flex", height: "100vh" }}>
      {/* Sidebar */}
      <Sidebar user={user} />

      {/* Main Content */}
      <main style={{ flex: 1, padding: "20px" }}>
      <header style={{ marginBottom: "20px" }}>          
        <h1>{title}</h1>
        </header>

        {children} {/* Role-specific content goes here */}
      </main>
    </div>
  );
};

export default BaseDashboard;
