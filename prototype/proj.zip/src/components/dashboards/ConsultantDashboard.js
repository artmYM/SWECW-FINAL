import React from "react";
import BaseDashboard from "./BaseDashboard";

const ConsultantDashboard = ({user}) => {
  return (
    <BaseDashboard title="Consultant Dashboard" user = {user}>
      <section>
        <h2>My Timesheets</h2>
        <p>View and submit your timesheets for approval.</p>
        <button>Submit New Timesheet</button>
      </section>
    </BaseDashboard>
  );
};

export default ConsultantDashboard;
