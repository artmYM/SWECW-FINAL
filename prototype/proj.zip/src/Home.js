import { useNavigate } from "react-router-dom";
import "./Home.css";

export default function Home() {
    const navigate = useNavigate();

    return (
        <>

        <div className="home-container">
            <section className="home">
                <div className="home-text">
                    <h1>Effortless <span>Timesheets</span> for Professionals</h1>
                    <p>Manage work hours efficiently with this time tracking system.</p>
                    <div className="home-buttons">
                        <button className="btn primary" onClick={() => navigate("/login")}>Get Started</button>
                    </div>
                </div>
            </section>

            <section className="features">
                <h2>Your Work, Organized.</h2>
                <div className="feature-cards">
                    <div className="feature-card">
                        <i className="fas fa-clock"></i>
                        <h3>Track Work Hours</h3>
                        <p>Log your work hours accurately and efficiently.</p>
                    </div>
                    <div className="feature-card">
                        <i className="fas fa-calendar-alt"></i>
                        <h3>Manage Schedules</h3>
                        <p>Stay on top of deadlines and manage your hours effortlessly.</p>
                    </div>
                    <div className="feature-card">
                        <i className="fas fa-file-alt"></i>
                        <h3>Generate Reports</h3>
                        <p>Export detailed reports for payroll processing.</p>
                    </div>
                </div>
            </section>
        </div>
        </>
    );
}
