import React from "react";
import { BrowserRouter as Router, Route, Routes, useLocation } from "react-router-dom";
import Home from "./Home";
import Login from "./Login";
import Navbar from "./Navbar";
import AdminDashboard from "./components/dashboards/AdminDashboard";
import ManagerDashboard from "./components/dashboards/ManagerDashboard";
import ConsultantDashboard from "./components/dashboards/ConsultantDashboard";


const PageLayout = ({ children }) => {
  const location = useLocation();

  return (
    <>
      <Navbar />
      {children}
    </>
  );
};

function App() {
  return (
    <Router>
      <PageLayout>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/login" element={<Login />} />
          <Route
            path="/managerDashboard"
            element={<ManagerDashboard user={{ name: "manager", role: "manager" }} />}
          />
          <Route
            path="/adminDashboard"
            element={<AdminDashboard user={{ name: "admin", role: "admin" }} />}
          />
          <Route
            path="/consultantDashboard"
            element={<ConsultantDashboard user={{ name: "consultant", role: "consultant" }} />}
          />
        </Routes>
      </PageLayout>
    </Router>
  );
}

export default App;
