const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
const app = express();

app.use(express.json());
app.use(cors()); // Allows requests from your React app's domain

// Create a MySQL connection
const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root', // MySQL username (default: 'root')
  port: 3306, // MySQL port (change if needed) - check your MySQL configuration
  password: '', // MySQL password (default: empty)
  database: 'timesheet' // MySQL db name
});

connection.connect(err => {
  if (err) {
    console.error('Error connecting to the database:', err);
    return;
  }
  console.log("Connected to MySQL database.");
});



// Start the server
const PORT = 3009; //Express server will run on port 3001
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
